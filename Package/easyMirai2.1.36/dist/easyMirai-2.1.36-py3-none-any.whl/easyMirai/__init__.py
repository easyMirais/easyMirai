from .method import (
    Mirai,
    Init
)
